

<!DOCTYPE html>
<html  lang="en">
<head>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Discover a delectable array of handcrafted food at Cafe Hungry Monkey. Our menu offer Sandwiches,Salads, Soups, Quiche, Paninis, Wraps, Burgers, Fries, Nachos, Chicken tenders with fresh ingredients and diverse flavors, satisfying every craving. Explore our tasty selection today">
    <meta name="keywords" content="Sandwiches,Salads, Soups, Quiche, Paninis, Wraps, Burgers, Fries, Nachos, Chicken tenders">
    <title>Cafe Hungry Monkey</title>
        <!-- ========== Start Stylesheet ========== -->
      <meta charset="UTF-8">
      <title>Cafe Hungry Monkey</title>
      <!-- responsive meta -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- For IE -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- master stylesheet -->
      <link rel="stylesheet" href="public/css/style.css">
      <!-- Responsive stylesheet -->
      <link rel="stylesheet" href="public/css/responsive.css">
      <!-- Favicon -->
      <link rel="apple-touch-icon" sizes="180x180" href="public/uploads/favicon.png">
      <link rel="icon" type="image/png" href="public/uploads/favicon.png" sizes="32x32">
      <link rel="icon" type="image/png" href="public/uploads/favicon.png" sizes="16x16">
      
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Jost:wght@200;400;500;600;700;800&amp;display=swap">
    
    <!-- ========== End Stylesheet ========== -->
   
    <style>
        .header-area,
        ul.nav-menu li ul li a,
        .searchbar .input-search,
        .text-animated li a,
        .slider-one .owl-nav .owl-prev, 
        .slider-one .owl-nav .owl-next,
        .about-tab:before,
        .progress-gallery .bar-container .progress .progress-bar-custom,
        .choose-item:before,
        .feature-icon i,
        .feature-item:hover .feature-text,
        .bg-counterup,
        .portfolio-bg,
        .faq-header button.faq-button,
        .faq-header button.faq-button.collapsed:hover,
        .booking-area:before,
        .bg-booking,
        .team-carousel .owl-nav .owl-prev, 
        .team-carousel .owl-nav .owl-next,
        .team-text,
        .team-social li a:hover,
        .price-header i,
        .button-df a,
        .bg-testimonial,
        .testimonial-carousel .owl-dots .owl-dot,
        .blog-carousel .owl-nav .owl-prev, 
        .blog-carousel .owl-nav .owl-next,
        .blog-author li.blog-button a,
        .call-us:before,
        .footer-item h3:before,
        .footer-item h3:after,
        .footer-item .btn,
        .footer-item ul.footer-social li a,
        .scroll-top,
        .headstyle h4:before,
        .headstyle h4:after,
        .team-detail-text ul li a,
        .sidebar-item h3:before,
        .sidebar-item h3:after,
        .event-contact-item,
        .gallery-bg,
        .testimonial-grid .testimonial-description p:before, 
        .testimonial-two-carousel .testimonial-description p:before,
        .form-button .btn,
        .project-carousel .owl-nav .owl-prev, 
        .project-carousel .owl-nav .owl-next,
        .sidebar-item button,
        .contact-item:hover .contact-icon,
        .contact-form .btn,
        span.input-group-btn {
            background: #3367C1!important;
        }

        ul.nav-menu li:hover > a,
        .searchbar .search-button:hover,
        .text-animated li a:hover,
        .text-animated li:last-child a:hover,
        .slider-one .owl-nav .owl-prev:hover, 
        .slider-one .owl-nav .owl-next:hover,
        .feature-item:hover .feature-icon i,
        .services-text a:hover,
        .portfolio-menu li.filtr-active,
        .portfolio-menu li:hover,
        .portfolio-text h3 a:hover,
        .form-button .btn2:hover,
        .blog-item h3 a:hover,
        .blog-item span i,
        .blog-author li a i,
        .blog-author li a:hover,
        .call-us .button a:hover,
        .footer-item ul li a:hover,
        .team-info ul li span,
        li.event-header-left i,
        .recent-text a:hover,
        .event-contact-item:hover .event-contact-icon,
        .service-sidebar-item ul li a:hover,
        .portfolio-details ul li span,
        .sidebar-item ul li a:hover,
        .blog-one-text h3 a:hover,
        .blog-one-text ul li i,
        .single-blog ul li i,
        .contact-icon {
            color: #3367C1!important;   
        }

        .text-animated li a,
        .slider-one .owl-nav .owl-prev, 
        .slider-one .owl-nav .owl-next,
        .feature-icon i,
        .feature-item:hover .feature-text,
        .footer-item .form-control,
        .footer-item .btn,
        .footer-item ul.footer-social li a,
        .event-contact-item:hover .event-contact-icon,
        .form-control:focus,
        .sidebar-item button,
        .contact-item:hover .contact-icon,
        .contact-form .btn {
            border-color: #3367C1!important;      
        }

        .video-button span {
            border-left-color: #3367C1!important;         
        }

        .portfolio-menu li.filtr-active,
        .team-social li a:hover {
            border-bottom-color: #3367C1!important;            
        }

        .portfolio-menu li.filtr-active:before,
        .team-social li a:hover {
            border-top-color: #3367C1!important;               
        }

        ul.nav-menu li ul li:hover > a {
            background: #f1f1f1!important;
        }
        .text-animated li a:hover,
        .text-animated li:last-child a:hover,
        .slider-one .owl-nav .owl-prev:hover, 
        .slider-one .owl-nav .owl-next:hover {
            background: #fff!important;
            border-color: #fff!important;
        }
        .text-animated li:last-child a {
            background: #313131!important;
            border-color: #313131!important;
        }
        .blog-author li.blog-button a,
        .blog-author li.blog-button i,
        .footer-item ul.footer-social li a:hover,
        .contact-item:hover .contact-icon {
            color: #fff!important;
        }
        .feature-item:hover .feature-icon i,
        .faq-header button.faq-button.collapsed {
            background: #fff!important;
        }
        .team-carousel .owl-nav .owl-prev:hover, 
        .team-carousel .owl-nav .owl-next:hover,
        .blog-carousel .owl-nav .owl-prev:hover, 
        .blog-carousel .owl-nav .owl-next:hover,
        .button-df a:hover,
        .testimonial-carousel .owl-dots .owl-dot.active,
        .blog-author li.blog-button a:hover,
        .footer-item ul.footer-social li a:hover,
        .team-detail-text ul li a:hover,
        .form-button .btn:hover,
        .project-carousel .owl-nav .owl-prev:hover, 
        .project-carousel .owl-nav .owl-next:hover,
        .contact-form .btn:hover {
            background: #313131!important;
        }
        .footer-item ul.footer-social li a:hover,
        .contact-form .btn:hover {
            border-color: #313131!important;
        }
        .event-contact-item:hover,
        .faq-body,
        .feature-item:hover .feature-icon i, .faq-header button.faq-button.collapsed {
            background: #f5f5f5!important;
        }

        .booking-form input:focus,
        .booking-form textarea:focus {
            border-color: #fff!important;
        }

        .booking-form button[type="submit"] {
            background: #313131!important;
            color: #fff!important;
        }

        .booking-form button[type="submit"]:hover {
            background: #fff!important;
            color: #313131!important;
        }
    </style>

</head>
<body>
    <div class="boxed_wrapper">
        <!-- <div class="preloader"></div> -->
        <!-- main header -->
        <header class="main-header">
            <div class="inner-content">
               <!--Start header top -->
               <div class="header-top">
                  <div class="container">
                     <div class="outer-box clearfix">
                        <!--Top Left-->
                        <div class="top-left float-left">
                           <div class="phone-number clearfix">
                              <a style="color: white;"target="_blank" href="tel:9823319056"><span class="icon-phone"></span>+91 9823319056</a> &nbsp;
                               <a style="font-size: 17px;color: white;" target="_blank" href="/cdn-cgi/l/email-protection#7406151a1e1d00444c4441341319151d185a171b19"><span class="fa fa-envelope"></span>
                                <span class="__cf_email__" data-cfemail="7b091a1511120f4b434b4e3b1c161a121755181416">[email&#160;protected]</span></a>&nbsp;
                               
                           </div>
                        </div>
                        <!--Top Right-->    
                        <div class="top-right float-right">
                           
                           <div class="social-links">
                              <ul>
                                 
                                <li><a  target="_blank"  href="https://www.facebook.com/POKKETCAFEWagholi?mibextid=ZbWKwL"><i class="fa fa-facebook"></i></a></li>
                                <li><a  target="_blank"  href=""><i class="fa fa-youtube"></i></a></li>
                                <li><a  target="_blank"  href="https://www.instagram.com/hungrymonkey_wagholi?igsh=ZjJnemhzZGE5bHlk"><i class="fa fa-instagram"></i></a></li>                                 
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--End header top -->
               <!--Start Header upper -->
               <div class="header-upper">
                  <div class="container clearfix">
                     <div class="outer-box clearfix">
                        <div class="header-upper-left float-left">
                           <div class="logo">
                                <a class="navbar-brand" href="home.php">
                                    <img src="public/uploads/HMLogo.jpg"style="width:140px;height: 80px; margin-top: 50px ! important;" class="logo" alt="Logo">
                                </a>
                           </div>
                        </div>
                        <div class="header-upper-right float-left clearfix">
                            <div class="nav-outer clearfix">
                              <!-- Main Menu -->
                                <nav class="main-menu navbar-expand-lg">
                                    <div class="navbar-header">
                                            <!-- Toggle Button -->      
                                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            </button>
                                    </div>
                                
                                    <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                                            <ul class="navigation clearfix">
                                            <li>
                                                <a href="index.php"><span>Home</span></a>
                                                
                                            </li>
                                            <li class="dropdown">
                                                <a href="about.php"><span>About Us</span></a>
                                                
                                            </li>
                                            <li class="dropdown">
                                                <a href="menu.php"><span>Menu</span></a>
                                                
                                            </li>
                                            <li class="dropdown">
                                                <a href="Franchise.php"><span>Franchise</span></a>
                                            </li>
                                              
                                            <li><a href="Photo_gallery.php"><span>Gallery</span></a></li>

                                            <li><a href="Contact.php"><span>Contacts</span></a></li>
                                            
                                            </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>          
                </div>    
            </div>            <!-- Main Menu End-->
        </header>
<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image:url(public/uploads/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="inner-content text-center clearfix">
                    <div class="sec-title-style2 text-center">
                        <div class="title">GET IN TOUCH WITH US</div>
                         
                    </div>
                    <div class="breadcrumb-menu">
                        <ul class="clearfix">
                           <li><a href="index-2.html">Home</a></li>
                            <li class="active">Contact</li>
                        </ul>    
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area--> 


  <!--Start Contact Address Area-->
<section class="contact-address-area">
    <div class="container">
        <div class="sec-title-style1 text-center max-width">
            <div class="title">We are Here to Serve You</div>
            <div class="text"><div class="decor-left"><span></span></div><p>Quick Contact</p><div class="decor-right"><span></span></div></div>
             
        </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="contact-address-box">
                    <!--Start Single Contact Address Box-->
                    <div class="single-contact-address-box text-center">
                        <div class="icon-holder">
                            <span class="icon-clock-1">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span><span class="path13"></span><span class="path14"></span><span class="path15"></span><span class="path16"></span><span class="path17"></span><span class="path18"></span><span class="path19"></span><span class="path20"></span>
                            </span>
                        </div>
                        <h3>Call US</h3>
                        <h2>+91 9823319056</h2>
                    </div>
                    <!--End Single Contact Address Box-->
                    <!--Start Single Contact Address Box-->
                    <div class="single-contact-address-box main-branch">
                        <h3>Cafe Address</h3>
                        <div class="inner">
                            <ul>
                                <li>
                                    <div class="title">
                                        <h4>Address:</h4>
                                    </div>
                                    <div class="text">
                                        <p>Rainbow Crossroads, Shop No 12, Bakori phata, BJS chowk, Pune-412207, Maharashtra.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="title">
                                        <h4>Ph & Mail:</h4>
                                    </div>
                                    <div class="text">
                                        <p>+91 9823319056<br />
                                        <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="562437383c3f22666e666316313b373f3a7835393b">[email&#160;protected]</a></p>
                                    </div>
                                </li>
                                <li>
                                    <div class="title">
                                        <h4>Cafe Hrs:</h4>
                                    </div>
                                    <div class="text">
                                        <p>Mon-Sun: 9am to 11pm</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--End Single Contact Address Box-->
                    <!--Start Single Contact Address Box-->
                    <div class="single-contact-address-box text-center">
                        <div class="icon-holder">
                            <span class="icon-question-2">
                                <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span>
                            </span>
                        </div>
                        <h3>ORDER ON</h3>
                        <h2>+91 7020257175</h2>
                    </div>
                    <!--End Single Contact Address Box-->
                </div>
            </div>
        </div>
    </div>
</section>  
<!--End Contact Address Area-->  
 
<!--Start contact form area-->
<section class="contact-info-area" style="margin-top:-100px;">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="contact-form">



                    <div class="row">
                        <div class="col-xl-12">
                            <div class="sec-title-style1 float-left">
                                <div class="title">Let's Stay Connected!</div>
                                <div class="text"><div class="decor-left"><span></span></div><p>Contact Form</p></div>
                            </div>
                            
                        </div> 
                    </div>   
                    <div class="inner-box">
                        <form action="" class="" method="post" accept-charset="utf-8">
                            <div class="row">
                                <div class="col-xl-6 col-lg-12">
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="input-box">   
                                                <input type="text" name="name" required="" placeholder="Name" >
                                            </div> 
                                             <div class="input-box"> 
                                                <input type="text" name="mobile" required="" placeholder="Phone">
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="input-box"> 
                                                <input type="email" name="email"required=""  placeholder="Email" >
                                            </div>
                                             
                                        </div>  
                                    </div> 
                                       
                                </div>
                                <div class="col-xl-6 col-lg-12">
                                    <div class="input-box">    
                                        <textarea name="message" placeholder="Your Message..." ></textarea>
                                    </div>
                                    <div class="button-box">
                                        <input id="form_botcheck" name="form_contact" class="form-control" type="hidden" value="">
                                        <button type="submit" name = "submit">Send Message<span class="flaticon-next"></span></button>    
                                    </div>
                                              
                                </div> 
                            </div>
                            </form>                        
                    </div>
                    
                </div>
            </div>
            
        </div>
    </div>
</section>
<div>
    <div id="myModal" class="modal fade" role="dialog" >
        <div class="modal-dialog"style="width:300px;height:300px; padding-top: 100px;">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    
                </div>
                <div class="modal-body text-center">
                    <img src="public/images/email_success.jpeg">
                    </div>
                <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--End contact form area-->

<section class="google-map-area" style="margin-top:50px;">
    <div class="google-map-box">
        <iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d121012.72077208324!2d73.91448726750383!3d18.589923095732164!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x3bc2c49d11f5d24d%3A0x32eaff632d05fd29!2sRainbow%20Crossroads%2C%20Shop%20No%2012%2C%20Bakori%20phata%2C%20BJS%20chowk%2C%20Maharashtra%20412207!3m2!1d18.589941!2d73.996889!5e0!3m2!1sen!2sin!4v1723030777226!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>   
 
</section>



<!--Start Working Process Area Style2-->
<section class="">
    <div class="section-store-search animate-in-view" data-animation="zoomIn" style="background-size: cover; 
     	background-position: center center; background-image: url(public/images/locator.jpg); min-height: 50px;    border-radius: 0px;">
        <div class="store-locator">
            <div class="store-info">
                <span class="icon"><i class="po fa "></i></span>
                <div class="title-text">
                  <h2 style="font-family: 'Jost', sans-serif;" class="title">Order</h2>
                  <h3 style="font-family: 'Jost', sans-serif;" class="sub-title"><span ><b style="color: #e30b27;">Cafe Hungry Monkey</b></span></h3>
                </div>
            </div>
                <a href="https://www.zomato.com/pune/hungry-monkey-wagholi" target="_blank" class="woocommerce-LoopProduct-link">
                <img src="public/images/zomato-swiggy.png" class="img-responsive" style=" width: 380px; " alt="sandwich junction, fast food, restaurant near me, franchise opportunity, juice, shake, tasty, food, healthy, vegetarian, bhilai, raipur, chhattisgarh">
                </a>
        </div>
    </div>
</section>

<footer class="footer-area"> <!--FOOTER STARTS -->
    <div class="footer-shape-bg wow slideInRight" data-wow-delay="300ms" data-wow-duration="2500ms"></div>
    <div class="container">
        <div class="row">
            <!--Start single footer widget-->
            <div class="col-xl-6 col-lg-6 col-md-5 col-sm-12">
                <div class="single-footer-widget marbtm50">
                    <div class="title">
                        <h3>About Company</h3>
                        <div class="decor"><span></span></div>
                    </div>
                    <div class="footer-company-info-text">
                        <p>At Cafe Hungry Monkey, we're passionate about serving more than just great coffee and food - we're dedicated to creating a warm and inviting atmosphere where friends and family can gather, connect, and make memories.</p>
                        <a class="btn-two" href="about.php">More About Company<span class="icon-arrow"></span></a>
                    </div>  
                </div>
            </div>
            <!--End single footer widget-->
            <!--Start single footer widget-->
            <div class="col-xl-3 col-lg-6 col-md-7 col-sm-12">
                <div class="single-footer-widget useful-links-box marbtm50">
                    <div class="title">
                        <h3>Useful Links</h3>
                        <div class="decor"><span></span></div>
                    </div>
                    <div class="usefull-links">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6">
                                <ul >

                                    <li><a href="about.php"><span style="color: white !important">About</span></a></li>
                                    <li><a href="menu.php"><span style="color: white !important">Menu</span></a></li>
                                    <li><a href="Franchise.php"><span style="color: white !important">Franchise</span></a></li>
                                    <li><a href="Photo_gallery.php"><span style="color: white !important">Gallery</span></a></li>
                                    <li><a href="Contact.php"><span style="color: white !important">Contacts</span></a></li>
                                </ul>    
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
            <!--End single footer widget-->
           
            <!--Start single footer widget-->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                <div class="single-footer-widget">
                    <div class="title">
                        <h3>Contact Us</h3>
                        <div class="decor"><span></span></div>
                    </div>
                    <div class="subscribe-box">
                        <div class="text">
                            <p style="color: white !important">Address</p>
                            <p style="color: white !important"> Rainbow Crossroads, Shop No 12, Bakori phata, BJS chowk, Pune-412207, Maharashtra.</p>
                        </div>
                        <div class="">
                            <ul style="color: white;">
                                 <li ><i style = "color:#e30b27;"class="fa fa-phone"></i>  9823319056</li>
                                 <li><i style = "color:#e30b27;"class="fa fa-phone"></i>  7020257175</li> 
                                 <li><i style = "color:#e30b27;" class="fa fa-envelope"></i>  <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="681a090602011c5850585d280f05090104460b0705">[email&#160;protected]</a></li>
                                                         
                            </ul>
                        </div> 
                    </div>
                </div>
            </div>
            <!--End single footer widget-->
        </div>
    </div>
</footer>   
<!--End footer area-->


<!--Start footer bottom area-->
<section class="footer-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12">
                <div class="footer-bottom-content text-left">
                    <div class="copyright-text ">
                        <p> © 2025  All Rights Reserved by<a>Cafe Hungry Monkey</a><a href="#"></a></p>
                       
                    </div>
                </div>
               
            </div>
             <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12">
                <div class="footer-bottom-content text-right">
                    <div class="copyright-text ">
                        <p>Designed &<a href="" target="_blank">Created by Passion</a></p>
                        
                        
                    </div>
                </div>
               
            </div>
        </div>
    </div>    
</section>
<!--End footer bottom area-->   

</div> 
<!-- Scroll Top Button -->
<button class="scroll-top scroll-to-target" data-target="html">
    <span>Top</span>
</button>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="public/js/jquery.js"></script>
<script src="public/js/appear.js"></script>
<script src="public/js/bootstrap.bundle.min.js"></script>
<script src="public/js/bootstrap-select.min.js"></script>
<script src="public/js/isotope.js"></script>
<script src="public/js/jquery.bootstrap-touchspin.js"></script>
<script src="public/js/jquery.countTo.js"></script>
<script src="public/js/jquery.easing.min.js"></script>
<script src="public/js/jquery.enllax.min.js"></script>
<script src="public/js/jquery.fancybox.js"></script>
<script src="public/js/jquery.mixitup.min.js"></script>
<script src="public/js/jquery.paroller.min.js"></script>
<script src="public/js/owl.js"></script>
<script src="public/js/validation.js"></script>
<script src="public/js/wow.js"></script>

<script src="public/assets/language-switcher/jquery.polyglot.language.switcher.js"></script>
<script src="public/assets/timepicker/timePicker.js"></script>                       
<script src="public/assets/html5lightbox/html5lightbox.js"></script>
<!-- jQuery ui js -->
<script src="public/assets/jquery-ui-1.11.4/jquery-ui.js"></script>
<!--Revolution Slider-->
<script src="public/plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="public/plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="public/js/main-slider-script.js"></script>

<!-- thm custom script -->
<script src="public/js/custom.js"></script>


<script type="text/javascript">
   $(document).ready(function(){       
   $('#myModal').modal('hide');
    }); 
</script>
