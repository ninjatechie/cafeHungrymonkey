<!DOCTYPE html>
<html  lang="en">
<head>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Discover a delectable array of handcrafted food at Cafe Hungry Monkey. Our menu offer Sandwiches,Salads, Soups, Quiche, Paninis, Wraps, Burgers, Fries, Nachos, Chicken tenders with fresh ingredients and diverse flavors, satisfying every craving. Explore our tasty selection today">
    <meta name="keywords" content="Sandwiches,Salads, Soups, Quiche, Paninis, Wraps, Burgers, Fries, Nachos, Chicken tenders">
    <title>Cafe Hungry Monkey</title>
        <!-- ========== Start Stylesheet ========== -->
      <meta charset="UTF-8">
      <title>Cafe Hungry Monkey</title>
      <!-- responsive meta -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- For IE -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- master stylesheet -->
      <link rel="stylesheet" href="public/css/style.css">
      <!-- Responsive stylesheet -->
      <link rel="stylesheet" href="public/css/responsive.css">
      <!-- Favicon -->
      <link rel="apple-touch-icon" sizes="180x180" href="public/uploads/favicon.png">
      <link rel="icon" type="image/png" href="public/uploads/favicon.png" sizes="32x32">
      <link rel="icon" type="image/png" href="public/uploads/favicon.png" sizes="16x16">
      
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Jost:wght@200;400;500;600;700;800&amp;display=swap">
    
    <!-- ========== End Stylesheet ========== -->
   
    <style>
        .header-area,
        ul.nav-menu li ul li a,
        .searchbar .input-search,
        .text-animated li a,
        .slider-one .owl-nav .owl-prev, 
        .slider-one .owl-nav .owl-next,
        .about-tab:before,
        .progress-gallery .bar-container .progress .progress-bar-custom,
        .choose-item:before,
        .feature-icon i,
        .feature-item:hover .feature-text,
        .bg-counterup,
        .portfolio-bg,
        .faq-header button.faq-button,
        .faq-header button.faq-button.collapsed:hover,
        .booking-area:before,
        .bg-booking,
        .team-carousel .owl-nav .owl-prev, 
        .team-carousel .owl-nav .owl-next,
        .team-text,
        .team-social li a:hover,
        .price-header i,
        .button-df a,
        .bg-testimonial,
        .testimonial-carousel .owl-dots .owl-dot,
        .blog-carousel .owl-nav .owl-prev, 
        .blog-carousel .owl-nav .owl-next,
        .blog-author li.blog-button a,
        .call-us:before,
        .footer-item h3:before,
        .footer-item h3:after,
        .footer-item .btn,
        .footer-item ul.footer-social li a,
        .scroll-top,
        .headstyle h4:before,
        .headstyle h4:after,
        .team-detail-text ul li a,
        .sidebar-item h3:before,
        .sidebar-item h3:after,
        .event-contact-item,
        .gallery-bg,
        .testimonial-grid .testimonial-description p:before, 
        .testimonial-two-carousel .testimonial-description p:before,
        .form-button .btn,
        .project-carousel .owl-nav .owl-prev, 
        .project-carousel .owl-nav .owl-next,
        .sidebar-item button,
        .contact-item:hover .contact-icon,
        .contact-form .btn,
        span.input-group-btn {
            background: #3367C1!important;
        }

        ul.nav-menu li:hover > a,
        .searchbar .search-button:hover,
        .text-animated li a:hover,
        .text-animated li:last-child a:hover,
        .slider-one .owl-nav .owl-prev:hover, 
        .slider-one .owl-nav .owl-next:hover,
        .feature-item:hover .feature-icon i,
        .services-text a:hover,
        .portfolio-menu li.filtr-active,
        .portfolio-menu li:hover,
        .portfolio-text h3 a:hover,
        .form-button .btn2:hover,
        .blog-item h3 a:hover,
        .blog-item span i,
        .blog-author li a i,
        .blog-author li a:hover,
        .call-us .button a:hover,
        .footer-item ul li a:hover,
        .team-info ul li span,
        li.event-header-left i,
        .recent-text a:hover,
        .event-contact-item:hover .event-contact-icon,
        .service-sidebar-item ul li a:hover,
        .portfolio-details ul li span,
        .sidebar-item ul li a:hover,
        .blog-one-text h3 a:hover,
        .blog-one-text ul li i,
        .single-blog ul li i,
        .contact-icon {
            color: #3367C1!important;   
        }

        .text-animated li a,
        .slider-one .owl-nav .owl-prev, 
        .slider-one .owl-nav .owl-next,
        .feature-icon i,
        .feature-item:hover .feature-text,
        .footer-item .form-control,
        .footer-item .btn,
        .footer-item ul.footer-social li a,
        .event-contact-item:hover .event-contact-icon,
        .form-control:focus,
        .sidebar-item button,
        .contact-item:hover .contact-icon,
        .contact-form .btn {
            border-color: #3367C1!important;      
        }

        .video-button span {
            border-left-color: #3367C1!important;         
        }

        .portfolio-menu li.filtr-active,
        .team-social li a:hover {
            border-bottom-color: #3367C1!important;            
        }

        .portfolio-menu li.filtr-active:before,
        .team-social li a:hover {
            border-top-color: #3367C1!important;               
        }

        ul.nav-menu li ul li:hover > a {
            background: #f1f1f1!important;
        }
        .text-animated li a:hover,
        .text-animated li:last-child a:hover,
        .slider-one .owl-nav .owl-prev:hover, 
        .slider-one .owl-nav .owl-next:hover {
            background: #fff!important;
            border-color: #fff!important;
        }
        .text-animated li:last-child a {
            background: #313131!important;
            border-color: #313131!important;
        }
        .blog-author li.blog-button a,
        .blog-author li.blog-button i,
        .footer-item ul.footer-social li a:hover,
        .contact-item:hover .contact-icon {
            color: #fff!important;
        }
        .feature-item:hover .feature-icon i,
        .faq-header button.faq-button.collapsed {
            background: #fff!important;
        }
        .team-carousel .owl-nav .owl-prev:hover, 
        .team-carousel .owl-nav .owl-next:hover,
        .blog-carousel .owl-nav .owl-prev:hover, 
        .blog-carousel .owl-nav .owl-next:hover,
        .button-df a:hover,
        .testimonial-carousel .owl-dots .owl-dot.active,
        .blog-author li.blog-button a:hover,
        .footer-item ul.footer-social li a:hover,
        .team-detail-text ul li a:hover,
        .form-button .btn:hover,
        .project-carousel .owl-nav .owl-prev:hover, 
        .project-carousel .owl-nav .owl-next:hover,
        .contact-form .btn:hover {
            background: #313131!important;
        }
        .footer-item ul.footer-social li a:hover,
        .contact-form .btn:hover {
            border-color: #313131!important;
        }
        .event-contact-item:hover,
        .faq-body,
        .feature-item:hover .feature-icon i, .faq-header button.faq-button.collapsed {
            background: #f5f5f5!important;
        }

        .booking-form input:focus,
        .booking-form textarea:focus {
            border-color: #fff!important;
        }

        .booking-form button[type="submit"] {
            background: #313131!important;
            color: #fff!important;
        }

        .booking-form button[type="submit"]:hover {
            background: #fff!important;
            color: #313131!important;
        }
    </style>

</head>
<body>
    <div class="boxed_wrapper">
        <!-- <div class="preloader"></div> -->
        <!-- main header -->
        <header class="main-header">
            <div class="inner-content">
               <!--Start header top -->
               <div class="header-top">
                  <div class="container">
                     <div class="outer-box clearfix">
                        <!--Top Left-->
                        <div class="top-left float-left">
                           <div class="phone-number clearfix">
                              <a style="color: white;"target="_blank" href="tel:9823319056"><span class="icon-phone"></span>+91 9823319056</a> &nbsp;
                               <a style="font-size: 17px;color: white;" target="_blank" href="/cdn-cgi/l/email-protection#d2a0b3bcb8bba6e2eae2e792b5bfb3bbbefcb1bdbf"><span class="fa fa-envelope"></span>
                                <span class="__cf_email__" data-cfemail="1062717e7a79642028202550777d71797c3e737f7d">[email&#160;protected]</span></a>&nbsp;
                               
                           </div>
                        </div>
                        <!--Top Right-->    
                        <div class="top-right float-right">
                           
                           <div class="social-links">
                              <ul>
                                 
                                <li><a  target="_blank"  href="https://www.facebook.com/POKKETCAFEWagholi?mibextid=ZbWKwL"><i class="fa fa-facebook"></i></a></li>
                                <li><a  target="_blank"  href=""><i class="fa fa-youtube"></i></a></li>
                                <li><a  target="_blank"  href="https://www.instagram.com/hungrymonkey_wagholi?igsh=ZjJnemhzZGE5bHlk"><i class="fa fa-instagram"></i></a></li>                                 
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--End header top -->
               <!--Start Header upper -->
               <div class="header-upper">
                  <div class="container clearfix">
                     <div class="outer-box clearfix">
                        <div class="header-upper-left float-left">
                           <div class="logo">
                                <a class="navbar-brand" href="home.php">
                                    <img src="public/uploads/HMLogo.jpg"style="width:140px;height: 80px; margin-top: 50px ! important;" class="logo" alt="Logo">
                                </a>
                           </div>
                        </div>
                        <div class="header-upper-right float-left clearfix">
                            <div class="nav-outer clearfix">
                              <!-- Main Menu -->
                                <nav class="main-menu navbar-expand-lg">
                                    <div class="navbar-header">
                                            <!-- Toggle Button -->      
                                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            </button>
                                    </div>
                                
                                    <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                                            <ul class="navigation clearfix">
                                            <li>
                                                <a href="index.php"><span>Home</span></a>
                                                
                                            </li>
                                            <li class="dropdown">
                                                <a href="about.php"><span>About Us</span></a>
                                                
                                            </li>
                                            <li class="dropdown">
                                                <a href="menu.php"><span>Menu</span></a>
                                                
                                            </li>
                                            <li class="dropdown">
                                                <a href="Franchise.php"><span>Franchise</span></a>
                                            </li>
                                              
                                            <li><a href="Photo_gallery.php"><span>Gallery</span></a></li>

                                            <li><a href="Contact.php"><span>Contacts</span></a></li>
                                            
                                            </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>          
                </div>    
            </div>            <!-- Main Menu End-->
        </header>
         <!--Main Slider-->
         <section class="main-slider">
            <div class="rev_slider_wrapper fullwidthbanner-container"  id="rev_slider_one_wrapper" data-source="gallery">
               <div class="rev_slider fullwidthabanner" id="rev_slider_one" data-version="5.4.1">
                  <ul>
                    <li 
                        data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" 
                        data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1689" 
                        data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" 
                        data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off"
                        data-slotamount="default" data-thumb="public/uploads/service-4.jpg);" 
                        data-title="Slide Title" data-transition="parallaxvertical">
                            <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center"
                            data-bgrepeat="no-repeat" data-no-retina="" src="public/uploads/service-4.jpg" style= "height: 10px ! important;"> 
                            <div class="tp-caption" 
                            data-paddingbottom="[0,0,0,0]"
                            data-paddingleft="[0,0,0,0]"
                            data-paddingright="[0,0,0,0]"
                            data-paddingtop="[0,0,0,0]"
                            data-responsive_offset="on"
                            data-type="text"
                            data-height="none"
                            data-width="['800','800','600','400']"
                            data-whitespace="normal"
                            data-hoffset="['15','15','15','15']"
                            data-voffset="['-95','-95','-105','-100']"
                            data-x="['left','left','left','left']"
                            data-y="['middle','middle','middle','middle']"
                            data-textalign="['top','top','top','top']"
                            data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
                            style="z-index: 7; white-space: nowrap;">
                            <div class="slide-content left-slide">
                                <div class="big-title">
                                                                 
                                </div>
                            </div>
                            </div>
                    
                    </li>
                    
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" 
                    data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1689" data-masterspeed="default" data-param1=""
                    data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" 
                    data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="public/uploads/about-.jpg);" data-title="Slide Title" data-transition="parallaxvertical">
                        <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center"
                        data-bgrepeat="no-repeat" data-no-retina="" src="public/uploads/about-.jpg"> 
                        <div class="tp-caption" 
                           data-paddingbottom="[0,0,0,0]"
                           data-paddingleft="[0,0,0,0]"
                           data-paddingright="[0,0,0,0]"
                           data-paddingtop="[0,0,0,0]"
                           data-responsive_offset="on"
                           data-type="text"
                           data-height="none"
                           data-width="['800','800','600','400']"
                           data-whitespace="normal"
                           data-hoffset="['15','15','15','15']"
                           data-voffset="['-95','-95','-105','-100']"
                           data-x="['left','left','left','left']"
                           data-y="['middle','middle','middle','middle']"
                           data-textalign="['top','top','top','top']"
                           data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
                           style="z-index: 7; white-space: nowrap;">
                           <div class="slide-content left-slide">
                              <div class="big-title">
                                 </div>
                           </div>
                        </div>
                    </li>
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" 
                    data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1689" data-masterspeed="default" data-param1=""
                    data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" 
                    data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="public/uploads/service-6.jpg);" data-title="Slide Title" data-transition="parallaxvertical">
                        <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" 
                        data-bgrepeat="no-repeat" data-no-retina="" src="public/uploads/service-6.jpg"> 
                        <div class="tp-caption" 
                           data-paddingbottom="[0,0,0,0]"
                           data-paddingleft="[0,0,0,0]"
                           data-paddingright="[0,0,0,0]"
                           data-paddingtop="[0,0,0,0]"
                           data-responsive_offset="on"
                           data-type="text"
                           data-height="none"
                           data-width="['800','800','600','400']"
                           data-whitespace="normal"
                           data-hoffset="['15','15','15','15']"
                           data-voffset="['-95','-95','-105','-100']"
                           data-x="['left','left','left','left']"
                           data-y="['middle','middle','middle','middle']"
                           data-textalign="['top','top','top','top']"
                           data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
                           style="z-index: 7; white-space: nowrap;">
                           <div class="slide-content left-slide">
                              <div class="big-title">
                                                               </div>
                           </div>
                        </div>
                    </li>
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" 
                    data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1689"
                    data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" 
                    data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default"
                    data-thumb="public/uploads/fried-chicken-wrap-with-tomato-bell-peppers-french-fries-sauces.jpg);" data-title="Slide Title" data-transition="parallaxvertical">
                        <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" 
                        data-bgrepeat="no-repeat" data-no-retina="" src="public/uploads/fried-chicken-wrap-with-tomato-bell-peppers-french-fries-sauces.jpg"> 
                        <div class="tp-caption" 
                           data-paddingbottom="[0,0,0,0]"
                           data-paddingleft="[0,0,0,0]"
                           data-paddingright="[0,0,0,0]"
                           data-paddingtop="[0,0,0,0]"
                           data-responsive_offset="on"
                           data-type="text"
                           data-height="none"
                           data-width="['800','800','600','400']"
                           data-whitespace="normal"
                           data-hoffset="['15','15','15','15']"
                           data-voffset="['-95','-95','-105','-100']"
                           data-x="['left','left','left','left']"
                           data-y="['middle','middle','middle','middle']"
                           data-textalign="['top','top','top','top']"
                           data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
                           style="z-index: 7; white-space: nowrap;">
                           <div class="slide-content left-slide">
                              <div class="big-title">
                    </div>
                           </div>
                        </div>
                    </li>
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500"
                    data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1689"
                    data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" 
                    data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" 
                    data-thumb="public/uploads/momos.jpg);" data-title="Slide Title" data-transition="parallaxvertical">
                        <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" 
                        data-bgrepeat="no-repeat" data-no-retina="" src="public/uploads/momos.jpg"> 
                        <div class="tp-caption" 
                           data-paddingbottom="[0,0,0,0]"
                           data-paddingleft="[0,0,0,0]"
                           data-paddingright="[0,0,0,0]"
                           data-paddingtop="[0,0,0,0]"
                           data-responsive_offset="on"
                           data-type="text"
                           data-height="none"
                           data-width="['800','800','600','400']"
                           data-whitespace="normal"
                           data-hoffset="['15','15','15','15']"
                           data-voffset="['-95','-95','-105','-100']"
                           data-x="['left','left','left','left']"
                           data-y="['middle','middle','middle','middle']"
                           data-textalign="['top','top','top','top']"
                           data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'
                           style="z-index: 7; white-space: nowrap;">
                           <div class="slide-content left-slide">
                              <div class="big-title">
                                 Delicious Layers Explore the Irresistible World of Cafe Hungry Monkey</div>
                           </div>
                        </div>
                    </li>                   
                  </ul>
               </div>
            </div>
         </section>
         <!--End Main Slider-->

         <!--Start Booking Call Area-->
        <section class="highlights-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12">
                        <div class="highlights-content-box clearfix">
                            <!--Start single highlights box-->
                            <div class="single-highlights-box">
                                <div class="icon">
                                    <span class="icon-electrician"></span>    
                                </div>
                                <div class="title">
                                    <h3>Experienced Team</h3>
                                    
                                </div>
                            </div>
                            <!--End single highlights box-->
                            <!--Start single highlights box-->
                            <div class="single-highlights-box middle">
                                <div class="icon">
                                    <span class="icon-price-1"></span>    
                                </div>
                                <div class="title">
                                    <h3>Reasonable Price</h3>
                                
                                </div>
                            </div>
                            <!--End single highlights box-->     
                            <!--Start single highlights box-->
                            <div class="single-highlights-box">
                                <div class="icon">
                                    <span class="icon-award1"></span>    
                                </div>
                                <div class="title">
                                    <h3>Healthy food</h3>
                                
                                </div>
                            </div>
                            <!--End single highlights box-->          
                        </div>   
                    </div>
                </div> 
            </div>    
        </section>
        <!--End Booking Call Area-->   
        <!--Start about area Style2-->
        <section class="about-area-style2">
            <div class="pattern-layer paroller" data-paroller-factor="0.10" data-paroller-factor-lg="0.10"
            data-paroller-factor-md="0.10" data-paroller-factor-sm="0.10" data-paroller-type="foreground"
            data-paroller-direction="horizontal" style="background-image:url(public/images/pattern/pattern.jpg)">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12">
                        <div class="about-content-style2">
                            <div class="year-box">
                                <span class="icon-review"></span>
                                <p>EST 2016</p>    
                            </div>
                            <div class="inner-content">
                                
                                <div class="title">The Tale Behind the Brand</div>
                                <p><p>At Cafe Hungry Monkey, we're passionate about serving more than just great coffee and food - we're dedicated to creating a warm and inviting atmosphere where friends and family can gather, connect, and make memories. </p>
                                </p>
                                <div class="border-box"></div>
                            <div class="authorised-person">
                                    <h3>Mr. Ranjit Jadhav</h3>

                                    <span>Founder of Cafe hungry monkey</span>
                                </div>
                                
                                <div class="button">
                                    <a class="left" href="about.php">More About Us</a>    
                                    <a class="right" href="Contact.php">Know More</a>    
                                </div>
                            </div>    
                        </div>   
                    </div>
                </div> 
            </div>    
        </section><!--End about Area Style2-->
    


<!--Start Choose Area-->

<section class="choose-area" style="background-image:url(public/images/parallax-background/choose-bg.jpg);">
    <div class="container">
        <div class="choose-image-box">
            <img src="public/images/left_home.jpg" alt="Awesome Image">
        </div>
        <div class="row">
            <div class="col-xl-6">
                <div class="single-choose-box left">
                    <div class="icon">
                        <div class="count">03</div>
                        <span class="icon-award1"></span>
                    </div>
                    <div class="text">
                        <h3>CONTINUE HAND HOLDING AND SUPPORT</h3>
                        <p>helping in property finalization, we help
                         in hiring & Training of team, regular brand positioning and provide marketing help to retain and build customer base.</p>
                        
                    </div>
                    <div class="overlay-count">03</div>
                </div>    
            </div>
            <div class="col-xl-6">
                <div class="choose-content">
                    <div class="sec-title-style2">
                        <span>WHY</span>
                        <div class="title clr-white">Cafe Hungry Monkey</div>
                        <div class="decor"><span></span></div>
                        <div class="text">
                            <p>We are the brand of quality. Our food are made with love & served with a smile.</p>
                        </div>
                    </div>
                    <div class="inner-content">
                        <!--Start Single Choose Box-->
                        <div class="single-choose-box">
                            <div class="icon">
                                <div class="count">01</div>
                                <span class="icon-builder"></span>
                            </div>
                            <div class="text">
                                <h3>HIGH PROFITABILITY</h3>
                                <p>Cafe Hungry Monkey offers high margins and good return on investments with the philosophy that of mutual respectable profit sharing with our partners.
                                </p>
                            </div>
                            <div class="overlay-count">01</div>
                        </div>
                        <!--End Single Choose Box-->
                        <!--Start Single Choose Box-->
                        <div class="single-choose-box">
                            <div class="icon">
                                <div class="count">02</div>
                                <span class="icon-cost"></span>
                            </div>
                            <div class="text">
                                <h3>AFFORDABLE INVESTMENT</h3>
                                <p>We offer an extremely affordable investment option of 8-14 lakhs* only (including Franchise/Brand Fee) for the complete setup of the store with interior and all equipment & machines.
                                </p>
                            </div>
                            <div class="overlay-count">02</div>
                        </div>
                        <!--End Single Choose Box-->
                    </div>
                </div>    
            </div>
        </div>
    </div>
</section>
<!--End Choose Area-->




<!--Start Working Process Area Style2-->
<section class="working-process-area-style2">
    <div class="container">
        <div class="sec-title-style2 text-center">
            <span style="color: #131313; padding-top: 20px;">MOST POPULER</span>
            <div class="title">EXPLORE OUR MENUS</div>
            <div class="decor center"><span></span></div>
            <div class="text">
                <p style="color: #131313;">All our menu items are prepared daily with fresh, high-quality ingredients.</p>
            </div>
        </div>
        <div class="row">
                         <!--Start single product item-->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="single-product-item text-center">
                                <div class="img-holder">
                                    <img src="public/uploads/icecream.jpg" alt="Awesome Product Image">
                                </div>
                                <div class="title-holder text-center">
                                    <div class="static-content">
                                        <h3 class="title text-center"><a>Ice Cream</a></h3>
                                         
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
        	<!--End single product item-->
                            <!--Start single product item-->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="single-product-item text-center">
                                <div class="img-holder">
                                    <img src="public/uploads/service-4.jpg" alt="Awesome Product Image">
                                </div>
                                <div class="title-holder text-center">
                                    <div class="static-content">
                                        <h3 class="title text-center"><a href="">Burger</a></h3>
                                         
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
        	<!--End single product item-->
                            <!--Start single product item-->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="single-product-item text-center">
                                <div class="img-holder">
                                    <img src="public/uploads/mastani.jpg" alt="Awesome Product Image">
                                </div>
                                <div class="title-holder text-center">
                                    <div class="static-content">
                                        <h3 class="title text-center"><a href="">Mastani</a></h3>
                                         
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
        	<!--End single product item-->
                            <!--Start single product item-->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="single-product-item text-center">
                                <div class="img-holder">
                                    <img src="public/uploads/service-6.jpg" alt="Awesome Product Image">
                                </div>
                                <div class="title-holder text-center">
                                    <div class="static-content">
                                        <h3 class="title text-center"><a href="">Pizza</a></h3>
                                         
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
        	<!--End single product item-->
                            <!--Start single product item-->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="single-product-item text-center">
                                <div class="img-holder">
                                    <img src="public/uploads/nachos1.jpg" alt="Awesome Product Image">
                                </div>
                                <div class="title-holder text-center">
                                    <div class="static-content">
                                        <h3 class="title text-center"><a href="">Nachos</a></h3>
                                         
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
        	<!--End single product item-->
                            <!--Start single product item-->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="single-product-item text-center">
                                <div class="img-holder">
                                    <img src="public/uploads/coffee1.jpg" alt="Awesome Product Image">
                                </div>
                                <div class="title-holder text-center">
                                    <div class="static-content">
                                        <h3 class="title text-center"><a href="">Cold Coffee</a></h3>
                                         
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
        	<!--End single product item-->
            <!--Start single product item-->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="single-product-item text-center">
                                <div class="img-holder">
                                    <img src="public/uploads/about-.jpg" alt="Awesome Product Image">
                                </div>
                                <div class="title-holder text-center">
                                    <div class="static-content">
                                        <h3 class="title text-center"><a href="">Sandwich</a></h3>
                                         
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
        	<!--End single product item-->
            <!--Start single product item-->
            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                <div class="single-product-item text-center">
                    <div class="img-holder">
                        <img src="public/uploads/momosservice.jpg" alt="Awesome Product Image">
                    </div>
                    <div class="title-holder text-center">
                        <div class="static-content">
                            <h3 class="title text-center"><a href="">Momos</a></h3>
                             
                        </div>
                        
                    </div>
                </div>
            </div>
            <!--End single product item-->
            <!--Start single product item-->
            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                <div class="single-product-item text-center">
                    <div class="img-holder">
                        <img src="public/uploads/french.jpg" alt="Awesome Product Image">
                    </div>
                    <div class="title-holder text-center">
                        <div class="static-content">
                            <h3 class="title text-center"><a href="">French Fries & Wraps</a></h3>
                            
                        </div>
                        
                    </div>
                </div>
            </div>
            <!--End single product item-->
                                       
        </div>
    </div>
</section>
<!--End Working Process Area Style2-->





<!--Start Fact Counter Area-->
<section class="fact-counter-area" style="background-image:url(public/images/parallax-background/fact-counter-bg.jpg);">
    <div class="container">
        <div class="sec-title-style1 text-center max-width">
            <div class="title clr-white">Achivements In number</div>
            <div class="text clr-yellow">
                <div class="decor-left"><span></span></div><p>Interesting Facts</p><div class="decor-right"><span></span></div>
            </div>
             
        </div>
        <div class="row">
            <!--Start Single Fact Counter-->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                <div class="single-fact-counter text-center wow fadeInLeft" data-wow-delay="100ms" data-wow-duration="1500ms">
                    <div class="icon">
                        <span class="icon-design"></span>
                    </div>
                    <div class="count-box">
                        <h1>
                            <span class="timer add" data-from="1" data-to="7" data-speed="5000" data-refresh-interval="50"></span>
                        </h1>
                    </div>
                    <div class="border-box">
                        <div class="left-border"><span></span></div>
                        <div class="right-border"><span></span></div>
                    </div>
                    <div class="title">
                        <h3>Experience</h3>
                    </div>
                </div>
            </div>
            <!--End Single Fact Counter-->
            <!--Start Single Fact Counter-->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                <div class="single-fact-counter text-center wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="icon">
                        <span class="icon-builder1"></span>
                    </div>
                    <div class="count-box">
                        <h1>
                            <span class="timer add" data-from="1" data-to="1000" data-speed="5000" data-refresh-interval="50"></span>
                        </h1>
                    </div>
                    <div class="border-box">
                        <div class="left-border"><span></span></div>
                        <div class="right-border"><span></span></div>
                    </div>
                    <div class="title">
                        <h3>Customer Served</h3>
                    </div>
                </div>
            </div>
            <!--End Single Fact Counter-->
            <!--Start Single Fact Counter-->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                <div class="single-fact-counter text-center wow fadeInLeft" data-wow-delay="500ms" data-wow-duration="1500ms">
                    <div class="icon">
                        <span class="icon-map"></span>
                    </div>
                    <div class="count-box">
                        <h1>
                            <span class="timer add" data-from="1" data-to="3" data-speed="5000" data-refresh-interval="50"></span>
                        </h1>
                    </div>
                    <div class="border-box">
                        <div class="left-border"><span></span></div>
                        <div class="right-border"><span></span></div>
                    </div>
                    <div class="title">
                        <h3>Upcomming outlets</h3>
                    </div>
                </div>
            </div>
            <!--End Single Fact Counter-->
            <!--Start Single Fact Counter-->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                <div class="single-fact-counter text-center wow fadeInLeft" data-wow-delay="700ms" data-wow-duration="1500ms">
                    <div class="icon">
                        <span class="icon-review1"></span>
                    </div>
                    <div class="count-box">
                        <h1>
                            <span class="timer add" data-from="1" data-to="20" data-speed="5000" data-refresh-interval="50"></span>
                        </h1>
                    </div>
                    <div class="border-box">
                        <div class="left-border"><span></span></div>
                        <div class="right-border"><span></span></div>
                    </div>
                    <div class="title">
                        <h3>Target Outlets</h3>
                    </div>
                </div>
            </div>
            <!--End Single Fact Counter-->
        </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="start-project-button">
                    <!--<a href="#">Know more...!</a>-->
                </div>
            </div>
        </div>
        <div class="container main-project-style4">
            <div class="row">
                <!--Start single project style6-->
                <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 filter-item carpen paint">
                    <div class="single-project-style6">
                        <div class="img-holder">
                            <video controls width="400" height = "400" autoplay muted>
    							  <source src="public/v.mp4" type="video/mp4" />
                            </video>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 filter-item carpen paint">
                    <div class="single-project-style6">
                        <div class="img-holder">
                            <video controls width="400" height = "400" autoplay muted>
    							  <source src="public/images/cafehungrymonkey1.mp4" type="video/mp4" />							  
                            </video>
                        </div>
                    </div>
                </div>
                
            </div>
    	</div>
    </div>
</section>   
<!--End Fact Counter Area--> 
<!--Start Choosing Area--> 
<section class="choosimg-area" style="background-image:url(public/images/pricing-plan-bg.html);">
    
    <div class="container">
        <div class="sec-title-style1 text-center max-width">
            <div class="title">What we provide?</div>
            <div class="text"><div class="decor-left"><span></span></div><p>Features & Advantages</p><div class="decor-right"><span></span></div></div>
           
        </div>
        <div class="row">
            <!--Start Single Choosimg Box-->
            <div class="col-xl-3 col-lg-6">
                <div class="single-choosimg-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1200ms">
                    <div class="icon-holder">
                        <span class="icon-worker1">
                            <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span><span class="path13"></span>
                        </span>
                    </div>
                    <div class="text-holder">
                        <h3>Wastages reduce to nil</h3>
                        
                    </div>    
                </div>
            </div>
            <!--End Single Choosimg Box-->
            <!--Start Single Choosimg Box-->
            <div class="col-xl-3 col-lg-6">
                <div class="single-choosimg-box wow fadeInUp" data-wow-delay="100ms" data-wow-duration="1200ms">
                    <div class="icon-holder">
                        <span class="icon-money-back">
                            <span class="path1"></span><span class="path2"></span><span class="path3"></span>
                        </span>
                    </div>
                    <div class="text-holder">
                        <h3>Consistent innovations</h3>
                    </div>    
                </div>
            </div>
            <!--End Single Choosimg Box-->
             <!--Start Single Choosimg Box-->
            <div class="col-xl-3 col-lg-6">
                <div class="single-choosimg-box wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                    <div class="icon-holder">
                        <span class="icon-price2">
                            <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span><span class="path13"></span><span class="path14"></span><span class="path15"></span><span class="path16"></span>
                        </span>
                    </div>
                    <div class="text-holder">
                        <h3>Staff training</h3>
                        
                    </div>    
                </div>
            </div>
            <!--End Single Choosimg Box-->
            <!--Start Single Choosimg Box-->
            <div class="col-xl-3 col-lg-6">
                <div class="single-choosimg-box wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                    <div class="icon-holder">
                        <span class="icon-price2">
                            <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span><span class="path13"></span><span class="path14"></span><span class="path15"></span><span class="path16"></span>
                        </span>
                    </div>
                    <div class="text-holder">
                        <h3>Handsome ROI</h3>
                    </div>    
                </div>
            </div>
            <!--End Single Choosimg Box-->
            
            <!--Start Single Choosimg Box-->
            <div class="col-xl-3 col-lg-6">
                <div class="single-choosimg-box wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1200ms">
                    <div class="icon-holder">
                        <span class="icon-contract">
                            <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span><span class="path13"></span><span class="path14"></span><span class="path15"></span><span class="path16"></span><span class="path17"></span><span class="path18"></span><span class="path19"></span>
                        </span>
                    </div>
                    <div class="text-holder">
                        <h3>Centralized buying and sourcing</h3>
                      
                    </div>    
                </div>
            </div>
            <!--End Single Choosimg Box-->
            <!--Start Single Choosimg Box-->
            <div class="col-xl-3 col-lg-6">
                <div class="single-choosimg-box wow fadeInUp" data-wow-delay="400ms" data-wow-duration="1200ms">
                    <div class="icon-holder">
                        <span class="icon-call">
                            <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span>
                        </span>
                    </div>
                    <div class="text-holder">
                        <h3>End-to-End Logistic Support</h3>
                       
                    </div>    
                </div>
            </div>
            <!--End Single Choosimg Box-->
            
            <!--Start Single Choosimg Box-->
            <div class="col-xl-3 col-lg-6">
                <div class="single-choosimg-box wow fadeInUp" data-wow-delay="500ms" data-wow-duration="1200ms">
                    <div class="icon-holder">
                        <span class="icon-help-1">
                            <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span><span class="path13"></span><span class="path14"></span><span class="path15"></span><span class="path16"></span>
                        </span>
                    </div>
                    <div class="text-holder">
                        <h3>Brand recognition in market</h3>
                      
                    </div>    
                </div>
            </div>
            <!--End Single Choosimg Box-->
             <!--Start Single Choosimg Box-->
            <div class="col-xl-3 col-lg-6">
                <div class="single-choosimg-box wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1200ms">
                    <div class="icon-holder">
                        <span class="icon-price2">
                            <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span><span class="path13"></span><span class="path14"></span><span class="path15"></span><span class="path16"></span>
                        </span>
                    </div>
                    <div class="text-holder">
                        <h3>Menu, Merchandise & Brand </h3>
             
                    </div>    
                </div>
            </div>
            <!--End Single Choosimg Box-->
        </div>
    </div>
</section>
<!--End Choosing Area-->  


<!--Start Working Process Area Style2-->
<section class="">
    <div class="section-store-search animate-in-view" data-animation="zoomIn" style="background-size: cover; 
     	background-position: center center; background-image: url(public/images/locator.jpg); min-height: 50px;    border-radius: 0px;">
        <div class="store-locator">
            <div class="store-info">
                <span class="icon"><i class="po fa "></i></span>
                <div class="title-text">
                  <h2 style="font-family: 'Jost', sans-serif;" class="title">Order</h2>
                  <h3 style="font-family: 'Jost', sans-serif;" class="sub-title"><span ><b style="color: #e30b27;">Cafe Hungry Monkey</b></span></h3>
                </div>
            </div>
                <a href="https://www.zomato.com/pune/hungry-monkey-wagholi" target="_blank" class="woocommerce-LoopProduct-link">
                <img src="public/images/zomato-swiggy.png" class="img-responsive" style=" width: 380px; " alt="sandwich junction, fast food, restaurant near me, franchise opportunity, juice, shake, tasty, food, healthy, vegetarian, bhilai, raipur, chhattisgarh">
                </a>
        </div>
    </div>
</section>

<footer class="footer-area"> <!--FOOTER STARTS -->
    <div class="footer-shape-bg wow slideInRight" data-wow-delay="300ms" data-wow-duration="2500ms"></div>
    <div class="container">
        <div class="row">
            <!--Start single footer widget-->
            <div class="col-xl-6 col-lg-6 col-md-5 col-sm-12">
                <div class="single-footer-widget marbtm50">
                    <div class="title">
                        <h3>About Company</h3>
                        <div class="decor"><span></span></div>
                    </div>
                    <div class="footer-company-info-text">
                        <p>At Cafe Hungry Monkey, we're passionate about serving more than just great coffee and food - we're dedicated to creating a warm and inviting atmosphere where friends and family can gather, connect, and make memories.</p>
                        <a class="btn-two" href="about.php">More About Company<span class="icon-arrow"></span></a>
                    </div>  
                </div>
            </div>
            <!--End single footer widget-->
            <!--Start single footer widget-->
            <div class="col-xl-3 col-lg-6 col-md-7 col-sm-12">
                <div class="single-footer-widget useful-links-box marbtm50">
                    <div class="title">
                        <h3>Useful Links</h3>
                        <div class="decor"><span></span></div>
                    </div>
                    <div class="usefull-links">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6">
                                <ul >

                                    <li><a href="about.php"><span style="color: white !important">About</span></a></li>
                                    <li><a href="menu.php"><span style="color: white !important">Menu</span></a></li>
                                    <li><a href="Franchise.php"><span style="color: white !important">Franchise</span></a></li>
                                    <li><a href="Photo_gallery.php"><span style="color: white !important">Gallery</span></a></li>
                                    <li><a href="Contact.php"><span style="color: white !important">Contacts</span></a></li>
                                </ul>    
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
            <!--End single footer widget-->
           
            <!--Start single footer widget-->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                <div class="single-footer-widget">
                    <div class="title">
                        <h3>Contact Us</h3>
                        <div class="decor"><span></span></div>
                    </div>
                    <div class="subscribe-box">
                        <div class="text">
                            <p style="color: white !important">Address</p>
                            <p style="color: white !important"> Rainbow Crossroads, Shop No 12, Bakori phata, BJS chowk, Pune-412207, Maharashtra.</p>
                        </div>
                        <div class="">
                            <ul style="color: white;">
                                 <li ><i style = "color:#e30b27;"class="fa fa-phone"></i>  9823319056</li>
                                 <li><i style = "color:#e30b27;"class="fa fa-phone"></i>  7020257175</li> 
                                 <li><i style = "color:#e30b27;" class="fa fa-envelope"></i>  <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="5220333c383b26626a626712353f333b3e7c313d3f">[email&#160;protected]</a></li>
                                                         
                            </ul>
                        </div> 
                    </div>
                </div>
            </div>
            <!--End single footer widget-->
        </div>
    </div>
</footer>   
<!--End footer area-->


<!--Start footer bottom area-->
<section class="footer-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12">
                <div class="footer-bottom-content text-left">
                    <div class="copyright-text ">
                        <p> © 2025  All Rights Reserved by<a>Cafe Hungry Monkey</a><a href="#"></a></p>
                       
                    </div>
                </div>
               
            </div>
             <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12">
                <div class="footer-bottom-content text-right">
                    <div class="copyright-text ">
                        <p>Designed &<a href="" target="_blank">Created by Passion</a></p>
                        
                        
                    </div>
                </div>
               
            </div>
        </div>
    </div>    
</section>
<!--End footer bottom area-->   

</div> 
<!-- Scroll Top Button -->
<button class="scroll-top scroll-to-target" data-target="html">
    <span>Top</span>
</button>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="public/js/jquery.js"></script>
<script src="public/js/appear.js"></script>
<script src="public/js/bootstrap.bundle.min.js"></script>
<script src="public/js/bootstrap-select.min.js"></script>
<script src="public/js/isotope.js"></script>
<script src="public/js/jquery.bootstrap-touchspin.js"></script>
<script src="public/js/jquery.countTo.js"></script>
<script src="public/js/jquery.easing.min.js"></script>
<script src="public/js/jquery.enllax.min.js"></script>
<script src="public/js/jquery.fancybox.js"></script>
<script src="public/js/jquery.mixitup.min.js"></script>
<script src="public/js/jquery.paroller.min.js"></script>
<script src="public/js/owl.js"></script>
<script src="public/js/validation.js"></script>
<script src="public/js/wow.js"></script>

<script src="public/assets/language-switcher/jquery.polyglot.language.switcher.js"></script>
<script src="public/assets/timepicker/timePicker.js"></script>                       
<script src="public/assets/html5lightbox/html5lightbox.js"></script>
<!-- jQuery ui js -->
<script src="public/assets/jquery-ui-1.11.4/jquery-ui.js"></script>
<!--Revolution Slider-->
<script src="public/plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="public/plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="public/plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="public/js/main-slider-script.js"></script>

<!-- thm custom script -->
<script src="public/js/custom.js"></script>


<script type="text/javascript">
   $(document).ready(function(){       
   $('#myModal').modal('hide');
    }); 
</script>
